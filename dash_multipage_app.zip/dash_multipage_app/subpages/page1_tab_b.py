from dash import html
layout = html.Div(className="tab-wrap", children=[
    html.H4("Page 1 – Sub B"),
    html.P("Independent code here.")
])
