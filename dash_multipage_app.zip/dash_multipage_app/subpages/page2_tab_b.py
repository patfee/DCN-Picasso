from dash import html
layout = html.Div(className="tab-wrap", children=[
    html.H4("Page 2 – Details"),
    html.P("Own logic/callbacks if needed.")
])
